const FOV = 75;
const NEAR = 0.1;
const FAR = 1000;